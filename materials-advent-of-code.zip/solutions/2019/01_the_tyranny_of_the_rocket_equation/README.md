# Day 1, 2019: The Tyranny of the Rocket Equation

Resources:

- **Puzzle:** [adventofcode.com](https://adventofcode.com/2019/day/1)
- **Solution:** [realpython.com](https://realpython.com/python-advent-of-code/#practicing-advent-of-code-day-1-2019)
