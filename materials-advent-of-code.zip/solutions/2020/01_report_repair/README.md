# Day 1, 2020: Report Repair

Resources:

- **Puzzle:** [adventofcode.com](https://adventofcode.com/2020/day/1)
- **Solution:** [realpython.com](https://realpython.com/python-advent-of-code/#the-structure-of-a-solution)
