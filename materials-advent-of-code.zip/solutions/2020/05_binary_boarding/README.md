# Day 5, 2020: Binary Boarding

Resources:

- **Puzzle:** [adventofcode.com](https://adventofcode.com/2020/day/5)
- **Solution:** [realpython.com](https://realpython.com/python-advent-of-code/#practicing-advent-of-code-day-5-2020)
